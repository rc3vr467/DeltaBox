package io.nekohasekai.sagernet.bg

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.*
import android.widget.Toast
import io.nekohasekai.sagernet.Action
import io.nekohasekai.sagernet.BootReceiver
import io.nekohasekai.sagernet.BuildConfig
import io.nekohasekai.sagernet.R
import io.nekohasekai.sagernet.SagerNet
import io.nekohasekai.sagernet.aidl.ISagerNetService
import io.nekohasekai.sagernet.aidl.ISagerNetServiceCallback
import io.nekohasekai.sagernet.bg.proto.ProxyInstance
import io.nekohasekai.sagernet.database.DataStore
import io.nekohasekai.sagernet.database.SagerDatabase
import io.nekohasekai.sagernet.ktx.*
import io.nekohasekai.sagernet.plugin.PluginManager
import io.nekohasekai.sagernet.utils.DefaultNetworkListener
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import libcore.Libcore
import moe.matsuri.nb4a.Protocols
import moe.matsuri.nb4a.utils.Util
import java.net.UnknownHostException

class BaseService {

    enum class State(
        val canStop: Boolean = false,
        val started: Boolean = false,
        val connected: Boolean = false,
    ) {
        /**
         * Idle state is only used by UI and will never be returned by BaseService.
         */
        Idle, Connecting(true, true, false), Connected(true, true, true), Stopping, Stopped,
    }

    interface ExpectedException

    class Data internal constructor(private val service: Interface) {
        var state = State.Stopped
        var proxy: ProxyInstance? = null
        var notification: ServiceNotification? = null

        val receiver = broadcastReceiver { ctx, intent ->
            when (intent.action) {
                Intent.ACTION_SHUTDOWN -> service.persistStats()
                Action.RELOAD -> service.reload()
                // Action.SWITCH_WAKE_LOCK -> runOnDefaultDispatcher { service.switchWakeLock() }
                PowerManager.ACTION_DEVICE_IDLE_MODE_CHANGED -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        if (SagerNet.power.isDeviceIdleMode) {
                            proxy?.box?.sleep()
                        } else {
                            proxy?.box?.wake()
                            if (DataStore.wakeResetConnections) {
                                Libcore.resetAllConnections(true)
                            }
                        }
                    }
                }

                Action.RESET_UPSTREAM_CONNECTIONS -> runOnDefaultDispatcher {
                    Libcore.resetAllConnections(true)
                    runOnMainDispatcher {
                        Util.collapseStatusBar(ctx)
                        Toast.makeText(ctx, "Reset upstream connections done", Toast.LENGTH_SHORT)
                            .show()
                    }
                }

                else -> service.stopRunner()
            }
        }
        var closeReceiverRegistered = false

        val binder = Binder(this)
        var connectingJob: Job? = null

        fun changeState(s: State, msg: String? = null) {
            if (state == s && msg == null) return
            Logs.step("State: $state -> $s" + (if (msg != null) " | $msg" else ""))
            state = s
            DataStore.serviceState = s
            binder.stateChanged(s, msg)
        }
    }

    class Binder(private var data: Data? = null) : ISagerNetService.Stub(), CoroutineScope,
        AutoCloseable {
        private val callbacks = object : RemoteCallbackList<ISagerNetServiceCallback>() {
            override fun onCallbackDied(callback: ISagerNetServiceCallback?, cookie: Any?) {
                super.onCallbackDied(callback, cookie)
            }
        }

        val callbackIdMap = mutableMapOf<ISagerNetServiceCallback, Int>()

        override val coroutineContext = Dispatchers.Main.immediate + Job()

        override fun getState(): Int = (data?.state ?: State.Idle).ordinal
        override fun getProfileName(): String = data?.proxy?.displayProfileName ?: "Idle"

        override fun registerCallback(cb: ISagerNetServiceCallback, id: Int) {
            if (id == SagerConnection.CONNECTION_ID_RESTART_BG) {
                Runtime.getRuntime().exit(0)
                return
            }
            if (!callbackIdMap.contains(cb)) {
                callbacks.register(cb)
            }
            callbackIdMap[cb] = id
        }

        private val broadcastMutex = Mutex()

        suspend fun broadcast(work: (ISagerNetServiceCallback) -> Unit) {
            broadcastMutex.withLock {
                val count = callbacks.beginBroadcast()
                try {
                    repeat(count) {
                        try {
                            work(callbacks.getBroadcastItem(it))
                        } catch (_: RemoteException) {
                        } catch (_: Exception) {
                        }
                    }
                } finally {
                    callbacks.finishBroadcast()
                }
            }
        }

        override fun unregisterCallback(cb: ISagerNetServiceCallback) {
            callbackIdMap.remove(cb)
            callbacks.unregister(cb)
        }

        override fun urlTest(): Int {
            if (data?.proxy?.box == null) {
                error("core not started")
            }
            try {
                return Libcore.urlTest(
                    data!!.proxy!!.box, DataStore.connectionTestURL, 3000
                )
            } catch (e: Exception) {
                error(Protocols.genFriendlyMsg(e.readableMessage))
            }
        }

        fun stateChanged(s: State, msg: String?) = launch {
            val profileName = profileName
            broadcast { it.stateChanged(s.ordinal, profileName, msg) }
        }

        fun missingPlugin(pluginName: String) = launch {
            val profileName = profileName
            broadcast { it.missingPlugin(profileName, pluginName) }
        }

        override fun close() {
            callbacks.kill()
            cancel()
            data = null
        }
    }

    interface Interface {
        val data: Data
        val tag: String
        fun createNotification(profileName: String): ServiceNotification

        fun onBind(intent: Intent): IBinder? =
            if (intent.action == Action.SERVICE) data.binder else null

        fun reload() {
            if (DataStore.selectedProxy == 0L) {
                stopRunner(false, (this as Context).getString(R.string.profile_empty))
            }
            if (canReloadSelector()) {
                val ent = SagerDatabase.proxyDao.getById(DataStore.selectedProxy)
                val tag = data.proxy!!.config.profileTagMap[ent?.id] ?: ""
                if (tag.isNotBlank() && ent != null) {
                    // select from GUI
                    data.proxy!!.box.selectOutbound(tag)
                    // or select from webui
                    // => selector_OnProxySelected
                }
                return
            }
            val s = data.state
            when {
                s == State.Stopped -> startRunner()
                s.canStop -> stopRunner(true)
                else -> Logs.w("Illegal state $s when invoking use")
            }
        }

        fun canReloadSelector(): Boolean {
            if ((data.proxy?.config?.selectorGroupId ?: -1L) < 0) return false
            val ent = SagerDatabase.proxyDao.getById(DataStore.selectedProxy) ?: return false
            val tmpBox = ProxyInstance(ent)
            tmpBox.buildConfigTmp()
            if (tmpBox.lastSelectorGroupId == data.proxy?.lastSelectorGroupId) {
                return true
            }
            return false
        }

        /** Runs one URL test after connecting so the log says whether traffic really flows. */
        fun verifyConnectivity(proxy: ProxyInstance) {
            runOnDefaultDispatcher {
                delay(1500)
                if (data.state != State.Connected) return@runOnDefaultDispatcher
                val url = DataStore.connectionTestURL
                try {
                    val ms = Libcore.urlTest(proxy.box, url, 5000)
                    Logs.step("Connectivity check OK: $url -> ${ms}ms")
                } catch (e: Throwable) {
                    Logs.e("Connectivity check FAILED: $url -> ${e.readableMessage}")
                    Logs.w("Connected but no traffic through proxy: check server, DNS, routes and SplitTunnel list")
                }
            }
        }

        suspend fun startProcesses() {
            data.proxy!!.launch()
        }

        fun startRunner() {
            this as Context
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(Intent(this, javaClass))
            else startService(Intent(this, javaClass))
        }

        fun killProcesses() {
            data.proxy?.close()
            wakeLock?.apply {
                release()
                wakeLock = null
            }
            runOnDefaultDispatcher {
                DefaultNetworkListener.stop(this)
            }
        }

        fun stopRunner(restart: Boolean = false, msg: String? = null) {
            DataStore.baseService = null
            DataStore.vpnService = null

            if (data.state == State.Stopping) return
            Logs.section("Connection stop")
            Logs.step("Stop requested: state=${data.state}, restart=$restart, reason=${msg ?: "user/none"}")
            data.notification?.destroy()
            data.notification = null
            this as Service

            BlackWallEngine.stopNoiseInjection()
            data.changeState(State.Stopping)

            runOnMainDispatcher {
                data.connectingJob?.cancelAndJoin() // ensure stop connecting first
                // we use a coroutineScope here to allow clean-up in parallel
                coroutineScope {
                    killProcesses()
                    val data = data
                    if (data.closeReceiverRegistered) {
                        unregisterReceiver(data.receiver)
                        data.closeReceiverRegistered = false
                    }
                    data.proxy = null
                }

                // change the state
                data.changeState(State.Stopped, msg)
                Logs.step("Stopped" + (if (restart) " (restarting)" else ""))
                // stop the service if nothing has bound to it
                if (restart) startRunner() else {
                    stopSelf()
                }
            }
        }

        fun persistStats() {
            // TODO NEW save app stats?
        }

        // networks
        var upstreamInterfaceName: String?

        suspend fun preInit() {
            DefaultNetworkListener.start(this) {
                val link = it?.let { network -> SagerNet.connectivity.getLinkProperties(network) }
                if (link == null) {
                    // Network lost (or none available yet): tell the Go core's router
                    // there is no default interface right now, same as upstream libbox
                    // does for interfaceIndex == -1. Previously nothing told the core
                    // about this at all (see interface_monitor.go), so it always believed
                    // there was no interface and paused all traffic dispatch regardless
                    // of whether Android actually had a working network.
                    if (upstreamInterfaceName != null) {
                        Logs.step("Underlying network: $upstreamInterfaceName -> none")
                    }
                    upstreamInterfaceName = null
                    Libcore.updateDefaultInterface("")
                    return@start
                }
                SagerNet.underlyingNetwork = it
                DataStore.vpnService?.updateUnderlyingNetwork()
                //
                val oldName = upstreamInterfaceName
                if (oldName != link.interfaceName) {
                    upstreamInterfaceName = link.interfaceName
                    Logs.step("Underlying network: ${oldName ?: "none"} -> ${link.interfaceName} (dns=${link.dnsServers.joinToString { d -> d.hostAddress ?: "?" }})")
                }
                // Always push the current interface down to the Go core's router, not
                // only on a name change: this also covers the very first callback after
                // a cold start, where oldName starts out null and must still reach Go.
                Libcore.updateDefaultInterface(link.interfaceName ?: "")
                if (oldName != null && upstreamInterfaceName != null && oldName != upstreamInterfaceName) {
                    Logs.d("Network changed: $oldName -> $upstreamInterfaceName")
                    if (DataStore.networkChangeResetConnections) {
                        Libcore.resetAllConnections(true)
                    }
                }
            }
            // DefaultNetworkListener.start() above only *registers* a callback; on a cold
            // start of the :bg process, Android's ConnectivityManager callback can fire tens
            // of milliseconds AFTER this function returns. If we let the caller proceed
            // straight to building the TUN interface and starting the core (step [4/5]),
            // the VPN interface gets establish()'d and the proxy (e.g. WireGuard) starts
            // sending UDP packets before SagerNet.underlyingNetwork/setUnderlyingNetworks()
            // has ever been applied, which on some devices makes the very first outbound
            // packets fail with "sendmsg: input/output error" (handshake can still succeed
            // because it races in before this is checked, but then no data flows).
            // DefaultNetworkListener.get() awaits the first known network (or returns
            // immediately if one is already cached), so block briefly on it here. A short
            // timeout keeps a genuinely offline device from hanging the connect flow.
            withTimeoutOrNull(1500) {
                try {
                    DefaultNetworkListener.get()
                } catch (_: UnknownHostException) {
                    // no network at all yet; fall through and let core.start() fail/retry
                    // the normal way instead of blocking the whole timeout window.
                }
            }
        }

        var wakeLock: PowerManager.WakeLock?
        fun acquireWakeLock()

        suspend fun lateInit() {
            wakeLock?.apply {
                release()
                wakeLock = null
            }

            if (DataStore.acquireWakeLock) {
                acquireWakeLock()
                data.notification?.postNotificationWakeLockStatus(true)
            } else {
                data.notification?.postNotificationWakeLockStatus(false)
            }
        }

        fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
            DataStore.baseService = this

            val data = data
            if (data.state != State.Stopped) return Service.START_NOT_STICKY
            val profile = SagerDatabase.proxyDao.getById(DataStore.selectedProxy)
            this as Context
            val t0 = SystemClock.elapsedRealtime()
            Logs.section("Connection start")
            Logs.step(
                "App ${SagerNet.appVersionNameForDisplay} (${BuildConfig.VERSION_CODE}) | " +
                        "Android ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT}) | " +
                        "${Build.MANUFACTURER} ${Build.MODEL}"
            )
            Logs.step(
                "Settings: mode=${DataStore.serviceMode}, mtu=${DataStore.mtu}, " +
                        "ipv6=${DataStore.ipv6Mode}, bypassLan=${DataStore.bypassLan}, " +
                        "mixedPort=${DataStore.mixedPort}, logLevel=${DataStore.logLevel}"
            )
            Logs.step(
                "SplitTunnel: enabled=${DataStore.proxyApps}, " +
                        "mode=${if (DataStore.bypass) "bypass(selected apps skip VPN)" else "only(selected apps use VPN)"}, " +
                        "apps=${DataStore.individual.split('\n').count { it.isNotBlank() }}"
            )
            if (profile == null) { // gracefully shutdown: https://stackoverflow.com/q/47337857/2245107
                Logs.e("No profile selected (id=${DataStore.selectedProxy}), aborting start")
                data.notification = createNotification("")
                stopRunner(false, getString(R.string.profile_empty))
                return Service.START_NOT_STICKY
            }

            Logs.step(
                "Profile: [${profile.displayType()}] ${profile.displayName()} " +
                        "@ ${profile.displayAddress()} (id=${profile.id})"
            )
            val proxy = ProxyInstance(profile, this)
            data.proxy = proxy
            BootReceiver.enabled = DataStore.persistAcrossReboot
            if (!data.closeReceiverRegistered) {
                val filter = IntentFilter().apply {
                    addAction(Action.RELOAD)
                    addAction(Intent.ACTION_SHUTDOWN)
                    addAction(Action.CLOSE)
                    // addAction(Action.SWITCH_WAKE_LOCK)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        addAction(PowerManager.ACTION_DEVICE_IDLE_MODE_CHANGED)
                    }
                    addAction(Action.RESET_UPSTREAM_CONNECTIONS)
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    registerReceiver(
                        data.receiver,
                        filter,
                        "$packageName.SERVICE",
                        null,
                        Context.RECEIVER_EXPORTED
                    )
                } else {
                    registerReceiver(
                        data.receiver,
                        filter,
                        "$packageName.SERVICE",
                        null
                    )
                }
                data.closeReceiverRegistered = true
            }

            data.changeState(State.Connecting)
            runOnMainDispatcher {
                try {
                    data.notification = createNotification(ServiceNotification.genTitle(profile))

                    Logs.step("[1/5] Cleaning up old processes", SystemClock.elapsedRealtime() - t0)
                    Executable.killAll()    // clean up old processes
                    Logs.step("[2/5] Watching default network", SystemClock.elapsedRealtime() - t0)
                    preInit()
                    Logs.step("[3/5] Building config & loading core", SystemClock.elapsedRealtime() - t0)
                    proxy.init()
                    Logs.step("Config built and core loaded", SystemClock.elapsedRealtime() - t0)
                    DataStore.currentProfile = profile.id

                    proxy.processes = GuardedProcessPool {
                        Logs.w(it)
                        stopRunner(false, it.readableMessage)
                    }

                    Logs.step("[4/5] Starting core / VPN interface", SystemClock.elapsedRealtime() - t0)
                    startProcesses()
                    data.changeState(State.Connected)
                    Logs.step("[5/5] CONNECTED", SystemClock.elapsedRealtime() - t0)
                    verifyConnectivity(proxy)
                    BlackWallEngine.startNoiseInjection(GlobalScope)

                    lateInit()
                } catch (_: CancellationException) { // if the job was cancelled, it is canceller's responsibility to call stopRunner
                    Logs.w("Connection attempt cancelled after ${SystemClock.elapsedRealtime() - t0}ms")
                } catch (e: UnknownHostException) {
                    Logs.e("FAILED: cannot resolve server address (${e.message}) after ${SystemClock.elapsedRealtime() - t0}ms")
                    stopRunner(false, getString(R.string.invalid_server))
                } catch (e: PluginManager.PluginNotFoundException) {
                    Logs.e("FAILED: missing plugin '${e.plugin}'")
                    Toast.makeText(this@Interface, e.readableMessage, Toast.LENGTH_SHORT).show()
                    Logs.w(e)
                    data.binder.missingPlugin(e.plugin)
                    stopRunner(false, null)
                } catch (exc: Throwable) {
                    Logs.e("FAILED after ${SystemClock.elapsedRealtime() - t0}ms: ${exc.javaClass.simpleName}: ${exc.readableMessage}")
                    if (exc.javaClass.name.endsWith("proxyerror")) {
                        // error from golang
                        Logs.w(exc.readableMessage)
                    } else {
                        Logs.w(exc)
                    }
                    stopRunner(
                        false, "${getString(R.string.service_failed)}: ${exc.readableMessage}"
                    )
                } finally {
                    data.connectingJob = null
                }
            }
            return Service.START_NOT_STICKY
        }
    }

}